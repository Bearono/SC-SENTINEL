from core.risk_level import max_risk
from cve.dependency_parser import infer_components
from cve.nvd_client import query_nvd_by_keyword
from cve.osv_client import query_osv_package

def run_agent_a(source_files, metadata_files):
    components = infer_components(source_files, metadata_files)
    enriched = []

    for component in components:
        name = component["name"]
        matched = query_nvd_by_keyword(name) + query_osv_package(name, component.get("version"))

        risk = "unknown"
        for item in matched:
            risk = max_risk(risk, item.get("risk_level", "unknown"))

        enriched.append({
            **component,
            "matched_cves": matched,
            "risk_level": risk
        })

    return {
        "agent": "Agent A - Dependency Risk Identification",
        "components": enriched,
        "summary": {
            "total_components": len(enriched),
            "high_risk_components": sum(1 for c in enriched if c.get("risk_level") in {"high", "critical"})
        }
    }
