import re
from core.id_generator import make_id

FUNCTION_SIGNATURE_PATTERN = re.compile(
    r'^\s*(?:static\s+)?(?:inline\s+)?(?:[A-Za-z_][\w\s\*\(\)]*?)\s+([A-Za-z_][A-Za-z0-9_]*)\s*\([^;]*\)\s*\{'
)

def run_agent_b(source_files):
    all_functions = []
    for f in source_files:
        context = _extract_file_context(f["lines"])
        functions = _extract_functions_from_file(f)
        for fn in functions:
            fn["context"] = context
            all_functions.append(fn)

    for fn in all_functions:
        fn["call_chain_upstream"] = _infer_callers(fn, all_functions)

    slices = []
    for idx, fn in enumerate(all_functions, start=1):
        slices.append({
            "slice_id": make_id("SLICE", idx),
            "target_file": fn["file"],
            "target_function": fn["function_name"],
            "line_range": [fn["start_line"], fn["end_line"]],
            "call_chain_upstream": fn["call_chain_upstream"],
            "related_includes": fn["context"]["includes"],
            "related_macros": fn["context"]["macros"],
            "code": _format_slice_code(fn),
            "notes": "Part 0 slice: function body + file-level includes/macros + simple caller hints."
        })

    return {
        "agent": "Agent B - Context Pruning and Code Slicing",
        "slices": slices,
        "summary": {
            "total_slices": len(slices),
            "total_source_files": len(source_files)
        }
    }

def _extract_file_context(lines):
    includes = []
    macros = []
    for idx, line in enumerate(lines, start=1):
        stripped = line.strip()
        if stripped.startswith("#include"):
            includes.append({"line": idx, "code": stripped})
        if stripped.startswith("#define"):
            macros.append({"line": idx, "code": stripped})
    return {"includes": includes, "macros": macros}

def _extract_functions_from_file(file_obj):
    lines = file_obj["lines"]
    functions = []
    i = 0

    while i < len(lines):
        line = lines[i]
        match = FUNCTION_SIGNATURE_PATTERN.match(line)
        if not match:
            i += 1
            continue

        function_name = match.group(1)
        start = i
        brace_balance = 0
        seen_open = False
        j = i

        while j < len(lines):
            current = lines[j]
            brace_balance += current.count("{")
            brace_balance -= current.count("}")
            if "{" in current:
                seen_open = True
            if seen_open and brace_balance == 0:
                break
            j += 1

        body_lines = lines[start:j + 1]
        functions.append({
            "file": file_obj["relative_path"],
            "function_name": function_name,
            "start_line": start + 1,
            "end_line": j + 1,
            "body": "\n".join(body_lines)
        })
        i = j + 1

    return functions

def _infer_callers(target_fn, all_functions):
    callers = []
    target_name = target_fn["function_name"]
    for fn in all_functions:
        if fn is target_fn:
            continue
        if re.search(rf'\b{re.escape(target_name)}\s*\(', fn["body"]):
            callers.append({
                "function": fn["function_name"],
                "file": fn["file"],
                "line_range": [fn["start_line"], fn["end_line"]]
            })
    return callers

def _format_slice_code(fn):
    parts = []
    if fn["context"]["includes"]:
        parts.append("// Related includes")
        parts.extend([item["code"] for item in fn["context"]["includes"]])
    if fn["context"]["macros"]:
        parts.append("\n// Related macros")
        parts.extend([item["code"] for item in fn["context"]["macros"]])
    parts.append(f"\n// Target function: {fn['function_name']} ({fn['file']}:{fn['start_line']}-{fn['end_line']})")
    parts.append(fn["body"])
    return "\n".join(parts)
