import json
import re
from pathlib import Path

from core.id_generator import make_id
from core.llm_client import LLMClient, extract_json_object

"""
Agent C - Static Vulnerability Audit

Part 3 upgraded version:
- Keeps high-risk slice filtering from Part 1.2.
- Keeps source line mapping fix from Part 1.3.
- Adds optional LLM-based semantic audit.
- Keeps rule-based audit as fallback when:
  1. .env is not configured
  2. LLM call fails
  3. LLM output JSON cannot be parsed
  4. LLM returns no finding but rule engine has high-confidence pattern

Default behavior:
- If LLM_API_KEY / LLM_BASE_URL / LLM_MODEL are not configured, it will still run using rule fallback.
"""

FREE_PATTERN = re.compile(r'\bfree\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)')
DANGEROUS_COPY_PATTERN = re.compile(r'\b(strcpy|strcat|sprintf|memcpy|memmove)\s*\(')

HIGH_VALUE_RISK_KEYWORDS = {
    "malloc", "calloc", "realloc", "free",
    "strcpy", "strncpy", "strcat", "sprintf", "snprintf",
    "memcpy", "memmove", "gets", "scanf", "sscanf",
    "new", "delete"
}

TARGET_BODY_MARKER = "/* ===== Target Function Body ===== */"


def run_agent_c(agent_a_result, agent_b_result):
    findings = []
    audited_slices = []
    skipped_slices = []
    llm_errors = []

    llm_client = LLMClient()
    llm_available = llm_client.is_available()

    for slc in agent_b_result.get("slices", []):
        if not should_audit_slice(slc):
            skipped_slices.append({
                "slice_id": slc.get("slice_id"),
                "target_file": slc.get("target_file"),
                "target_function": slc.get("target_function"),
                "reason": "No memory-risk keyword found in this slice."
            })
            continue

        audited_slices.append({
            "slice_id": slc.get("slice_id"),
            "target_file": slc.get("target_file"),
            "target_function": slc.get("target_function"),
            "risk_keywords": slc.get("risk_keywords", [])
        })

        function_lines = extract_target_function_lines(slc)

        # Rule findings are always computed as fallback and comparison baseline.
        rule_findings = rule_audit_slice(slc, function_lines)

        if llm_available:
            try:
                llm_findings = llm_audit_slice(llm_client, agent_a_result, slc, function_lines)
                if llm_findings:
                    findings.extend(llm_findings)
                else:
                    # If LLM returns no vulnerabilities but rule engine found clear risky pattern,
                    # keep the rule result as fallback.
                    findings.extend(rule_findings)
            except Exception as exc:
                llm_errors.append({
                    "slice_id": slc.get("slice_id"),
                    "target_file": slc.get("target_file"),
                    "target_function": slc.get("target_function"),
                    "error": str(exc)
                })
                findings.extend(rule_findings)
        else:
            findings.extend(rule_findings)

    findings = deduplicate_findings(findings)

    for idx, finding in enumerate(findings, start=1):
        finding["finding_id"] = make_id("FINDING", idx)

    return {
        "agent": "Agent C - Static Vulnerability Audit",
        "audit_mode": "llm_with_rule_fallback" if llm_available else "rule_fallback_only",
        "static_findings": findings,
        "audited_slices": audited_slices,
        "skipped_slices": skipped_slices,
        "llm_errors": llm_errors,
        "summary": {
            "total_input_slices": len(agent_b_result.get("slices", [])),
            "audited_slices": len(audited_slices),
            "skipped_slices": len(skipped_slices),
            "total_findings": len(findings),
            "high_risk_findings": sum(
                1 for f in findings if f.get("risk_level") in {"high", "critical"}
            ),
            "llm_available": llm_available,
            "llm_error_count": len(llm_errors)
        }
    }


# ----------------------------------------------------------------------
# Audit gating
# ----------------------------------------------------------------------

def should_audit_slice(slc):
    risk_keywords = set(slc.get("risk_keywords", []))
    return bool(risk_keywords & HIGH_VALUE_RISK_KEYWORDS)


# ----------------------------------------------------------------------
# LLM audit
# ----------------------------------------------------------------------

def llm_audit_slice(llm_client, agent_a_result, slc, function_lines):
    prompt = load_prompt()
    user_content = build_llm_user_content(agent_a_result, slc, function_lines)

    messages = [
        {
            "role": "system",
            "content": prompt
        },
        {
            "role": "user",
            "content": user_content
        }
    ]

    raw = llm_client.chat(messages, temperature=0)
    parsed = extract_json_object(raw)

    return normalize_llm_findings(parsed, slc)


def load_prompt():
    prompt_path = Path("prompts") / "static_audit_prompt.txt"
    if prompt_path.exists():
        return prompt_path.read_text(encoding="utf-8")
    return (
        "You are a C/C++ security auditing expert. "
        "Return strict JSON only."
    )


def build_llm_user_content(agent_a_result, slc, function_lines):
    component_context = summarize_component_context(agent_a_result)
    numbered_code = "\n".join(
        f'{item["source_line"]}: {item["code"]}'
        for item in function_lines
    )

    return f"""
请审计下面这个 C/C++ 函数切片。

【切片信息】
slice_id: {slc.get("slice_id")}
file: {slc.get("target_file")}
function: {slc.get("target_function")}
line_range: {slc.get("line_range")}
risk_keywords: {slc.get("risk_keywords")}
call_chain_upstream: {json.dumps(slc.get("call_chain_upstream", []), ensure_ascii=False)}
callee_functions: {json.dumps(slc.get("callee_functions", []), ensure_ascii=False)}

【组件风险上下文】
{component_context}

【带原始源码行号的目标函数代码】
{numbered_code}

请只返回严格 JSON。
""".strip()


def summarize_component_context(agent_a_result):
    components = []
    for comp in agent_a_result.get("components", []):
        components.append({
            "name": comp.get("name"),
            "version": comp.get("version"),
            "risk_level": comp.get("risk_level"),
            "top_vulnerabilities": [
                {
                    "id": v.get("id") or v.get("cve_id"),
                    "summary": v.get("summary"),
                    "risk_level": v.get("risk_level")
                }
                for v in comp.get("top_vulnerabilities", [])[:3]
            ]
        })
    return json.dumps(components, ensure_ascii=False, indent=2)


def normalize_llm_findings(parsed, slc):
    if not isinstance(parsed, dict):
        return []

    raw_findings = parsed.get("findings", [])
    if not parsed.get("has_vulnerability") or not raw_findings:
        return []

    result = []
    for item in raw_findings:
        line_range = item.get("line_range") or slc.get("line_range")

        if not valid_line_range(line_range, slc):
            line_range = clamp_line_range(line_range, slc)

        result.append({
            "finding_id": "PENDING",
            "source_slice_id": slc["slice_id"],
            "file": slc["target_file"],
            "function": slc["target_function"],
            "line_range": line_range,
            "cwe_id": item.get("cwe_id", "UNKNOWN"),
            "vulnerability_type": item.get("vulnerability_type", "Unknown"),
            "risk_level": normalize_risk(item.get("risk_level", "medium")),
            "trigger_condition": item.get("trigger_condition", ""),
            "evidence": item.get("evidence", []),
            "confidence": normalize_confidence(item.get("confidence", 0.5)),
            "suggested_fix": item.get("suggested_fix", ""),
            "static_status": "suspected",
            "audit_source": "llm"
        })

    return result


def valid_line_range(line_range, slc):
    if not isinstance(line_range, list) or len(line_range) != 2:
        return False
    start, end = line_range
    if not isinstance(start, int) or not isinstance(end, int):
        return False
    return slc["line_range"][0] <= start <= end <= slc["line_range"][1]


def clamp_line_range(line_range, slc):
    start, end = slc["line_range"]

    if isinstance(line_range, list) and len(line_range) == 2:
        raw_start, raw_end = line_range
        if isinstance(raw_start, int) and isinstance(raw_end, int):
            return [
                max(start, min(raw_start, end)),
                max(start, min(raw_end, end))
            ]

    return [start, end]


def normalize_risk(risk):
    risk = str(risk or "medium").lower()
    if risk in {"critical", "high", "medium", "low", "unknown"}:
        return risk
    return "medium"


def normalize_confidence(value):
    try:
        value = float(value)
    except Exception:
        return 0.5
    return max(0.0, min(value, 1.0))


# ----------------------------------------------------------------------
# Function body extraction and source line mapping
# ----------------------------------------------------------------------

def extract_target_function_lines(slc):
    code = slc.get("code", "")
    function_start_line = slc["line_range"][0]

    if TARGET_BODY_MARKER in code:
        body = code.split(TARGET_BODY_MARKER, 1)[1]
    else:
        body = code

    raw_lines = body.splitlines()

    while raw_lines and raw_lines[0].strip() == "":
        raw_lines.pop(0)

    function_lines = []
    for idx, line in enumerate(raw_lines, start=0):
        function_lines.append({
            "source_line": function_start_line + idx,
            "code": line
        })

    return function_lines


# ----------------------------------------------------------------------
# Rule-based fallback audit
# ----------------------------------------------------------------------

def rule_audit_slice(slc, function_lines):
    results = []
    results.extend(_detect_uaf_and_double_free(slc, function_lines))
    results.extend(_detect_overflow(slc, function_lines))

    for item in results:
        item["audit_source"] = "rule_fallback"

    return results


def _detect_uaf_and_double_free(slc, function_lines):
    results = []
    freed = {}

    for item in function_lines:
        source_line = item["source_line"]
        line = item["code"]

        m = FREE_PATTERN.search(line)
        if m:
            ptr = m.group(1)
            if ptr in freed:
                results.append(_finding(
                    slc, "CWE-415", "Double Free", "high",
                    [freed[ptr]["source_line"], source_line],
                    [
                        f"Pointer '{ptr}' is first freed at source line {freed[ptr]['source_line']}.",
                        f"Pointer '{ptr}' is freed again at source line {source_line}: {line.strip()}"
                    ],
                    f"Execution reaches free({ptr}) twice without reset or reallocation.",
                    f"Set {ptr} to NULL after free and avoid duplicate ownership."
                ))
            else:
                freed[ptr] = {
                    "source_line": source_line,
                    "code": line
                }
            continue

        for ptr, free_info in list(freed.items()):
            if re.search(rf'\b{re.escape(ptr)}\s*=\s*NULL\s*;', line):
                freed.pop(ptr, None)
                continue

            if (
                re.search(rf'\*\s*{re.escape(ptr)}\b', line)
                or re.search(rf'\b{re.escape(ptr)}\s*\[', line)
                or re.search(rf'\b{re.escape(ptr)}\s*->', line)
            ):
                results.append(_finding(
                    slc, "CWE-416", "Use After Free", "high",
                    [free_info["source_line"], source_line],
                    [
                        f"Pointer '{ptr}' is freed at source line {free_info['source_line']}.",
                        f"Pointer '{ptr}' is used again at source line {source_line}: {line.strip()}"
                    ],
                    f"Pointer '{ptr}' is dereferenced or accessed after free.",
                    f"Do not access {ptr} after free; set it to NULL and guard future uses."
                ))
                freed.pop(ptr, None)
                break

    return results


def _detect_overflow(slc, function_lines):
    results = []

    for idx, item in enumerate(function_lines):
        source_line = item["source_line"]
        line = item["code"]

        if not DANGEROUS_COPY_PATTERN.search(line):
            continue

        before = "\n".join(
            previous["code"]
            for previous in function_lines[max(0, idx - 8):idx]
        )

        if re.search(r'\bchar\s+[A-Za-z_][A-Za-z0-9_]*\s*\[\s*\d+\s*\]', before):
            cwe = "CWE-121"
            vuln_type = "Stack Buffer Overflow"
            risk = "high"
        elif "malloc" in before:
            cwe = "CWE-122"
            vuln_type = "Heap Buffer Overflow"
            risk = "high"
        else:
            cwe = "CWE-122"
            vuln_type = "Possible Buffer Overflow"
            risk = "medium"

        results.append(_finding(
            slc, cwe, vuln_type, risk,
            [source_line, source_line],
            [
                f"Dangerous copy-style function call at source line {source_line}: {line.strip()}",
                "Rule fallback cannot fully prove destination bounds."
            ],
            "Oversized or attacker-controlled input may reach a copy operation without sufficient length validation.",
            "Validate length before copying and use bounded APIs with explicit destination size."
        ))

    return results


def _finding(slc, cwe, vuln_type, risk, source_line_range, evidence, trigger, fix):
    return {
        "finding_id": "PENDING",
        "source_slice_id": slc["slice_id"],
        "file": slc["target_file"],
        "function": slc["target_function"],
        "line_range": source_line_range,
        "cwe_id": cwe,
        "vulnerability_type": vuln_type,
        "risk_level": risk,
        "trigger_condition": trigger,
        "evidence": evidence,
        "confidence": 0.65,
        "suggested_fix": fix,
        "static_status": "suspected"
    }


# ----------------------------------------------------------------------
# Deduplication
# ----------------------------------------------------------------------

def deduplicate_findings(findings):
    seen = set()
    result = []

    for finding in findings:
        key = (
            finding.get("source_slice_id"),
            finding.get("cwe_id"),
            tuple(finding.get("line_range", []))
        )
        if key in seen:
            continue
        seen.add(key)
        result.append(finding)

    return result
