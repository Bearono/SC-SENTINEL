import re
from core.id_generator import make_id

"""
Agent C - Static Vulnerability Audit

Part 1.3 upgraded version:
- Keep Part 1.2 high-risk slice filtering.
- Fix line number mapping.
- Agent C now audits only the original target function body extracted from Agent B slice.
- line_range is mapped back to the original source file line range.

Why this matters:
Agent B's slice["code"] contains many added context lines:
  includes / macros / types / globals / comments
If Agent C directly counts lines in slice["code"], the reported line numbers will be wrong.
"""

FREE_PATTERN = re.compile(r'\bfree\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)')
DANGEROUS_COPY_PATTERN = re.compile(r'\b(strcpy|strcat|sprintf|memcpy|memmove)\s*\(')

HIGH_VALUE_RISK_KEYWORDS = {
    "malloc", "calloc", "realloc", "free",
    "strcpy", "strncpy", "strcat", "sprintf", "snprintf",
    "memcpy", "memmove", "gets", "scanf", "sscanf",
    "new", "delete"
}

TARGET_BODY_MARKER = "/* ===== Target Function Body ===== */"


def run_agent_c(agent_a_result, agent_b_result):
    """
    Input:
        agent_a_result: dependency risk result
        agent_b_result: code slices

    Output:
        static_findings plus audit statistics

    Part 1.3 behavior:
        - Audit only high-risk slices.
        - Extract the real target function body from slice["code"].
        - Convert local body line numbers back to original source file line numbers.
    """
    findings = []
    audited_slices = []
    skipped_slices = []

    for slc in agent_b_result.get("slices", []):
        if not should_audit_slice(slc):
            skipped_slices.append({
                "slice_id": slc.get("slice_id"),
                "target_file": slc.get("target_file"),
                "target_function": slc.get("target_function"),
                "reason": "No memory-risk keyword found in this slice."
            })
            continue

        audited_slices.append({
            "slice_id": slc.get("slice_id"),
            "target_file": slc.get("target_file"),
            "target_function": slc.get("target_function"),
            "risk_keywords": slc.get("risk_keywords", [])
        })

        function_lines = extract_target_function_lines(slc)
        findings.extend(_detect_uaf_and_double_free(slc, function_lines))
        findings.extend(_detect_overflow(slc, function_lines))

    for idx, finding in enumerate(findings, start=1):
        finding["finding_id"] = make_id("FINDING", idx)

    return {
        "agent": "Agent C - Static Vulnerability Audit",
        "static_findings": findings,
        "audited_slices": audited_slices,
        "skipped_slices": skipped_slices,
        "summary": {
            "total_input_slices": len(agent_b_result.get("slices", [])),
            "audited_slices": len(audited_slices),
            "skipped_slices": len(skipped_slices),
            "total_findings": len(findings),
            "high_risk_findings": sum(
                1 for f in findings if f.get("risk_level") in {"high", "critical"}
            )
        }
    }


def should_audit_slice(slc):
    """
    Decide whether this slice should be audited by Agent C.

    For the future LLM version, this function is the gatekeeper before calling the LLM API.
    """
    risk_keywords = set(slc.get("risk_keywords", []))
    return bool(risk_keywords & HIGH_VALUE_RISK_KEYWORDS)


def extract_target_function_lines(slc):
    """
    Extract original target function body from Agent B's LLM-friendly slice.

    Agent B builds slice["code"] like:
        metadata
        related includes
        related macros
        related types
        related globals
        /* ===== Target Function Body ===== */
        <real function body>

    We only audit <real function body>.

    Return:
        [
            {"source_line": 3, "code": "void uaf_case(int flag) {"},
            {"source_line": 4, "code": "    int *p = ..."},
            ...
        ]
    """
    code = slc.get("code", "")
    function_start_line = slc["line_range"][0]

    if TARGET_BODY_MARKER in code:
        body = code.split(TARGET_BODY_MARKER, 1)[1]
    else:
        # Fallback: audit whole code if marker is missing.
        body = code

    raw_lines = body.splitlines()

    # Agent B usually inserts one blank line after the marker.
    # Remove leading empty lines so local line 1 corresponds to function_start_line.
    while raw_lines and raw_lines[0].strip() == "":
        raw_lines.pop(0)

    function_lines = []
    for idx, line in enumerate(raw_lines, start=0):
        function_lines.append({
            "source_line": function_start_line + idx,
            "code": line
        })

    return function_lines


def _detect_uaf_and_double_free(slc, function_lines):
    results = []
    freed = {}

    for item in function_lines:
        source_line = item["source_line"]
        line = item["code"]

        m = FREE_PATTERN.search(line)
        if m:
            ptr = m.group(1)
            if ptr in freed:
                results.append(_finding(
                    slc, "CWE-415", "Double Free", "high",
                    [freed[ptr]["source_line"], source_line],
                    [
                        f"Pointer '{ptr}' is first freed at source line {freed[ptr]['source_line']}.",
                        f"Pointer '{ptr}' is freed again at source line {source_line}: {line.strip()}"
                    ],
                    f"Execution reaches free({ptr}) twice without reset or reallocation.",
                    f"Set {ptr} to NULL after free and avoid duplicate ownership."
                ))
            else:
                freed[ptr] = {
                    "source_line": source_line,
                    "code": line
                }
            continue

        for ptr, free_info in list(freed.items()):
            if re.search(rf'\b{re.escape(ptr)}\s*=\s*NULL\s*;', line):
                freed.pop(ptr, None)
                continue

            if (
                re.search(rf'\*\s*{re.escape(ptr)}\b', line)
                or re.search(rf'\b{re.escape(ptr)}\s*\[', line)
                or re.search(rf'\b{re.escape(ptr)}\s*->', line)
            ):
                results.append(_finding(
                    slc, "CWE-416", "Use After Free", "high",
                    [free_info["source_line"], source_line],
                    [
                        f"Pointer '{ptr}' is freed at source line {free_info['source_line']}.",
                        f"Pointer '{ptr}' is used again at source line {source_line}: {line.strip()}"
                    ],
                    f"Pointer '{ptr}' is dereferenced or accessed after free.",
                    f"Do not access {ptr} after free; set it to NULL and guard future uses."
                ))
                freed.pop(ptr, None)
                break

    return results


def _detect_overflow(slc, function_lines):
    results = []

    for idx, item in enumerate(function_lines):
        source_line = item["source_line"]
        line = item["code"]

        if not DANGEROUS_COPY_PATTERN.search(line):
            continue

        before = "\n".join(
            previous["code"]
            for previous in function_lines[max(0, idx - 8):idx]
        )

        if re.search(r'\bchar\s+[A-Za-z_][A-Za-z0-9_]*\s*\[\s*\d+\s*\]', before):
            cwe = "CWE-121"
            vuln_type = "Stack Buffer Overflow"
            risk = "high"
        elif "malloc" in before:
            cwe = "CWE-122"
            vuln_type = "Heap Buffer Overflow"
            risk = "high"
        else:
            cwe = "CWE-122"
            vuln_type = "Possible Buffer Overflow"
            risk = "medium"

        results.append(_finding(
            slc, cwe, vuln_type, risk,
            [source_line, source_line],
            [
                f"Dangerous copy-style function call at source line {source_line}: {line.strip()}",
                "Part 1.3 rule-based audit cannot fully prove destination bounds."
            ],
            "Oversized or attacker-controlled input may reach a copy operation without sufficient length validation.",
            "Validate length before copying and use bounded APIs with explicit destination size."
        ))

    return results


def _finding(slc, cwe, vuln_type, risk, source_line_range, evidence, trigger, fix):
    """
    source_line_range is already mapped to the original file line range.
    """
    return {
        "finding_id": "PENDING",
        "source_slice_id": slc["slice_id"],
        "file": slc["target_file"],
        "function": slc["target_function"],
        "line_range": source_line_range,
        "cwe_id": cwe,
        "vulnerability_type": vuln_type,
        "risk_level": risk,
        "trigger_condition": trigger,
        "evidence": evidence,
        "confidence": 0.65,
        "suggested_fix": fix,
        "static_status": "suspected"
    }
