import re
from core.id_generator import make_id

FREE_PATTERN = re.compile(r'\bfree\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)')
DANGEROUS_COPY_PATTERN = re.compile(r'\b(strcpy|strcat|sprintf|memcpy|memmove)\s*\(')

def run_agent_c(agent_a_result, agent_b_result):
    findings = []

    for slc in agent_b_result.get("slices", []):
        lines = slc["code"].splitlines()
        findings.extend(_detect_uaf_and_double_free(slc, lines))
        findings.extend(_detect_overflow(slc, lines))

    for idx, finding in enumerate(findings, start=1):
        finding["finding_id"] = make_id("FINDING", idx)

    return {
        "agent": "Agent C - Static Vulnerability Audit",
        "static_findings": findings,
        "summary": {
            "total_findings": len(findings),
            "high_risk_findings": sum(1 for f in findings if f.get("risk_level") in {"high", "critical"})
        }
    }

def _detect_uaf_and_double_free(slc, lines):
    results = []
    freed = {}

    for local_idx, line in enumerate(lines, start=1):
        m = FREE_PATTERN.search(line)
        if m:
            ptr = m.group(1)
            if ptr in freed:
                results.append(_finding(
                    slc, "CWE-415", "Double Free", "high",
                    [freed[ptr], local_idx],
                    [
                        f"Pointer '{ptr}' appears to be freed earlier in this slice.",
                        f"Pointer '{ptr}' is freed again: {line.strip()}"
                    ],
                    f"Execution reaches free({ptr}) twice without reset or reallocation.",
                    f"Set {ptr} to NULL after free and avoid duplicate ownership."
                ))
            else:
                freed[ptr] = local_idx
            continue

        for ptr, free_line in list(freed.items()):
            if re.search(rf'\b{re.escape(ptr)}\s*=\s*NULL\s*;', line):
                freed.pop(ptr, None)
                continue
            if (
                re.search(rf'\*\s*{re.escape(ptr)}\b', line)
                or re.search(rf'\b{re.escape(ptr)}\s*\[', line)
                or re.search(rf'\b{re.escape(ptr)}\s*->', line)
            ):
                results.append(_finding(
                    slc, "CWE-416", "Use After Free", "high",
                    [free_line, local_idx],
                    [
                        f"Pointer '{ptr}' is freed earlier in this slice.",
                        f"Pointer '{ptr}' appears to be used after free: {line.strip()}"
                    ],
                    f"Pointer '{ptr}' is dereferenced or accessed after free.",
                    f"Do not access {ptr} after free; set it to NULL and guard future uses."
                ))
                freed.pop(ptr, None)
                break

    return results

def _detect_overflow(slc, lines):
    results = []
    for local_idx, line in enumerate(lines, start=1):
        if not DANGEROUS_COPY_PATTERN.search(line):
            continue

        before = "\n".join(lines[max(0, local_idx - 8):local_idx])
        if re.search(r'\bchar\s+[A-Za-z_][A-Za-z0-9_]*\s*\[\s*\d+\s*\]', before):
            cwe = "CWE-121"
            vuln_type = "Stack Buffer Overflow"
            risk = "high"
        elif "malloc" in before:
            cwe = "CWE-122"
            vuln_type = "Heap Buffer Overflow"
            risk = "high"
        else:
            cwe = "CWE-122"
            vuln_type = "Possible Buffer Overflow"
            risk = "medium"

        results.append(_finding(
            slc, cwe, vuln_type, risk,
            [local_idx, local_idx],
            [
                f"Dangerous copy-style function call: {line.strip()}",
                "Part 0 rule-based audit cannot fully prove destination bounds."
            ],
            "Oversized or attacker-controlled input may reach a copy operation without sufficient length validation.",
            "Validate length before copying and use bounded APIs with explicit destination size."
        ))
    return results

def _finding(slc, cwe, vuln_type, risk, local_line_range, evidence, trigger, fix):
    absolute_start = slc["line_range"][0] + max(local_line_range[0] - 1, 0)
    absolute_end = slc["line_range"][0] + max(local_line_range[1] - 1, 0)
    return {
        "finding_id": "PENDING",
        "source_slice_id": slc["slice_id"],
        "file": slc["target_file"],
        "function": slc["target_function"],
        "line_range": [absolute_start, absolute_end],
        "cwe_id": cwe,
        "vulnerability_type": vuln_type,
        "risk_level": risk,
        "trigger_condition": trigger,
        "evidence": evidence,
        "confidence": 0.65,
        "suggested_fix": fix,
        "static_status": "suspected"
    }
