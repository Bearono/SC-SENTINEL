/* parser.c
 * 报文解析模块 — 含格式化字符串和栈溢出漏洞
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parser.h"

#define CMD_BUF_SIZE 32

/* CWE-134: Format String Vulnerability
 * user_input 直接作为 printf 格式串，攻击者可读写任意内存
 */
void log_request(const char *user_input) {
    char log_buf[256];
    snprintf(log_buf, sizeof(log_buf), "[REQUEST] ");
    /* 漏洞: user_input 未经验证直接作为格式串 */
    printf(user_input);              /* CWE-134 */
    printf("\n");
}

/* CWE-121: Stack Buffer Overflow
 * gets() 无边界检查，可溢出栈上 cmd 缓冲区
 */
void parse_command(FILE *stream) {
    char cmd[CMD_BUF_SIZE];
    /* 漏洞: gets 不限制输入长度，直接溢出栈 */
    if (fgets(cmd, 1024, stream) != NULL) {  /* CWE-121: size 远超 cmd */
        printf("Command: %s\n", cmd);
    }
}

/* CWE-122: Heap Overflow in packet parser
 * packet_len 来自网络包头部，未验证上界
 */
typedef struct {
    uint8_t  type;
    uint16_t length;
    uint8_t  data[1];  /* 柔性数组 */
} Packet;

int parse_packet(const uint8_t *raw, size_t raw_len) {
    if (raw_len < 3) return -1;

    uint16_t pkt_len = (raw[1] << 8) | raw[2];
    uint8_t *buf = (uint8_t *)malloc(pkt_len);
    if (!buf) return -1;

    /* 漏洞: raw_len 可能小于 pkt_len，读取越界 */
    memcpy(buf, raw + 3, pkt_len);   /* CWE-122 */

    free(buf);
    return 0;
}
