#ifndef PARSER_H
#define PARSER_H
#include <stdint.h>
#include <stdio.h>
void log_request(const char *user_input);
void parse_command(FILE *stream);
int  parse_packet(const uint8_t *raw, size_t raw_len);
#endif
