// session.cpp
// 会话管理模块（C++）— 含资源泄漏和 UAF
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include "session.h"

struct Session {
    char  *token;
    int    uid;
    bool   authenticated;
    Session *prev;
    Session *next;
};

static Session *session_list = nullptr;

// CWE-416: Use-After-Free via dangling list pointer
Session *session_create(int uid, const char *token) {
    Session *s = new Session();
    s->token = strdup(token);
    s->uid   = uid;
    s->authenticated = false;
    s->prev  = nullptr;
    s->next  = session_list;
    if (session_list) session_list->prev = s;
    session_list = s;
    return s;
}

void session_destroy(Session *s) {
    if (!s) return;
    if (s->prev) s->prev->next = s->next;
    if (s->next) s->next->prev = s->prev;
    if (session_list == s) session_list = s->next;
    free(s->token);
    delete s;
    // 漏洞: 调用方可能仍持有 s 的引用并继续使用
}

// CWE-122: Heap overflow in token copy
bool session_authenticate(Session *s, const char *password) {
    if (!s) return false;
    char local_token[16];  // 固定大小
    // 漏洞: s->token 长度未检查，可溢出 local_token
    strcpy(local_token, s->token);  // CWE-121/122
    return strcmp(local_token, password) == 0;
}

// CWE-415: Double free in error path
int session_reset(Session *s) {
    if (!s) return -1;
    char *old_token = s->token;
    s->token = strdup("reset_token");
    if (!s->token) {
        free(old_token);  // 第一次 free
        s->token = old_token;  // 恢复（但 old_token 已释放）
        free(s->token);        // CWE-415: double free
        return -1;
    }
    free(old_token);
    return 0;
}
