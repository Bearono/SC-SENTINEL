#ifndef SSL_HANDLER_H
#define SSL_HANDLER_H
#include <stdint.h>
#include <stddef.h>
typedef struct SSLContext SSLContext;
unsigned char *handle_heartbeat(const unsigned char *payload, uint16_t payload_len);
SSLContext    *ssl_init(const char *cert, size_t cert_len);
void           ssl_destroy(SSLContext *ctx);
int            ssl_renegotiate(void);
#endif
