/* network.c
 * 网络收发模块 — 含整数溢出导致的堆溢出
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "network.h"

#define MAX_CHUNK 4096

/* CWE-190 + CWE-122: 整数溢出导致堆溢出
 * count * size 可能溢出 size_t，导致 malloc 分配不足
 */
void *alloc_recv_buffer(size_t count, size_t size) {
    /* 漏洞: 未检查 count * size 是否溢出 */
    void *buf = malloc(count * size);  /* 溢出时分配极小缓冲区 */
    return buf;
}

/* CWE-122: 接收数据长度未验证
 * recv_len 来自网络头部，可超过 buf 大小
 */
int recv_frame(unsigned char *buf, size_t buf_size,
               size_t recv_len) {
    if (!buf) return -1;
    /* 漏洞: recv_len 未与 buf_size 比较 */
    memset(buf, 0, recv_len);   /* CWE-122: recv_len > buf_size 时越界写 */
    return (int)recv_len;
}

/* CWE-416: UAF in connection pool
 * conn 被放入 free_list 后，active_list 仍持有引用
 */
typedef struct Conn {
    int    fd;
    char   addr[64];
    int    in_use;
} Conn;

#define MAX_CONN 32
static Conn  conn_pool[MAX_CONN];
static Conn *free_list[MAX_CONN];
static int   free_count = 0;

Conn *conn_acquire(int fd, const char *addr) {
    for (int i = 0; i < MAX_CONN; i++) {
        if (!conn_pool[i].in_use) {
            conn_pool[i].fd     = fd;
            conn_pool[i].in_use = 1;
            strncpy(conn_pool[i].addr, addr, 63);
            return &conn_pool[i];
        }
    }
    return NULL;
}

void conn_release(Conn *c) {
    if (!c) return;
    c->in_use = 0;
    free_list[free_count++ % MAX_CONN] = c;
    /* 漏洞: 调用方持有的指针现在在 free_list 中，
     * 下次 conn_acquire 会覆写同一 Conn，形成 UAF */
}

void conn_debug_print(Conn *c) {
    /* CWE-416: c 可能已经在 free_list 中被覆写 */
    printf("conn fd=%d addr=%s in_use=%d\n",
           c->fd, c->addr, c->in_use);
}
