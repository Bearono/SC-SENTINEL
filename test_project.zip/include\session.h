#ifndef SESSION_H
#define SESSION_H
struct Session;
Session *session_create(int uid, const char *token);
void     session_destroy(Session *s);
bool     session_authenticate(Session *s, const char *password);
int      session_reset(Session *s);
#endif
