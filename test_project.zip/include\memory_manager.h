#ifndef MEMORY_MANAGER_H
#define MEMORY_MANAGER_H
#include <stddef.h>
typedef struct Node Node;
Node *node_create(int id, const char *data);
void  node_free(Node *node);
void  node_print_all(void);
char *safe_copy(const char *src, size_t src_len);
int   process_buffer(unsigned char *buf, size_t len);
#endif
