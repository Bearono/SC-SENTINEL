/* memory_manager.c
 * 内存池管理模块 — 含多处内存安全漏洞
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "memory_manager.h"

#define POOL_SIZE 16

typedef struct Node {
    int   id;
    char *data;
    struct Node *next;
} Node;

static Node *pool[POOL_SIZE];
static int   pool_count = 0;

/* CWE-416: Use-After-Free
 * node 被 free 后，仍通过 pool[] 指针访问 node->data
 */
Node *node_create(int id, const char *data) {
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node) return NULL;
    node->id   = id;
    node->data = strdup(data);
    node->next = NULL;
    pool[pool_count++ % POOL_SIZE] = node;
    return node;
}

void node_free(Node *node) {
    if (!node) return;
    free(node->data);
    free(node);
    /* 漏洞: pool[] 中仍保留悬空指针，后续 node_print_all 会解引用 */
}

void node_print_all(void) {
    for (int i = 0; i < pool_count && i < POOL_SIZE; i++) {
        /* CWE-416: pool[i] 可能已被 node_free 释放，此处 UAF */
        printf("node[%d]: id=%d data=%s\n",
               i, pool[i]->id, pool[i]->data);
    }
}

/* CWE-122: Heap Buffer Overflow
 * 用户传入的 src_len 未经验证，可溢出 dst 缓冲区
 */
char *safe_copy(const char *src, size_t src_len) {
    char *dst = (char *)malloc(64);  /* 固定 64 字节 */
    if (!dst) return NULL;
    memcpy(dst, src, src_len);       /* 若 src_len > 64 则溢出 */
    dst[63] = '\0';
    return dst;
}

/* CWE-415: Double Free
 * error 路径下 buf 被 free 两次
 */
int process_buffer(unsigned char *buf, size_t len) {
    unsigned char *tmp = (unsigned char *)malloc(len);
    if (!tmp) return -1;

    memcpy(tmp, buf, len);

    if (len == 0) {
        free(tmp);   /* 第一次 free */
        goto cleanup;
    }

    /* 正常处理 */
    tmp[0] ^= 0xFF;

cleanup:
    free(tmp);       /* CWE-415: len==0 时 double free */
    return 0;
}
