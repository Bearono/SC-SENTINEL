/* ssl_handler.c
 * SSL/TLS 握手与数据处理 — 模拟 Heartbleed 风格漏洞
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ssl_handler.h"

#define MAX_PAYLOAD 65535

/* CWE-122: Heap Buffer Overflow (Heartbleed 风格)
 * payload_len 由客户端控制，未验证实际 payload 大小
 * 导致 memcpy 越界读取服务端堆内存
 */
unsigned char *handle_heartbeat(const unsigned char *payload,
                                 uint16_t payload_len) {
    /* 分配响应缓冲区（大小由客户端指定）*/
    unsigned char *response = (unsigned char *)malloc(payload_len);
    if (!response) return NULL;

    /* 漏洞: 直接以 payload_len 拷贝，但 payload 实际长度可能远小于 payload_len */
    memcpy(response, payload, payload_len);  /* CWE-122 */
    return response;
}

/* CWE-416: Use-After-Free in SSL context
 * ssl_ctx 被释放后，renegotiate 仍尝试使用
 */
typedef struct {
    char   *cert_buf;
    size_t  cert_len;
    int     is_valid;
} SSLContext;

static SSLContext *g_ctx = NULL;

SSLContext *ssl_init(const char *cert, size_t cert_len) {
    SSLContext *ctx = (SSLContext *)malloc(sizeof(SSLContext));
    if (!ctx) return NULL;
    ctx->cert_buf = (char *)malloc(cert_len);
    if (!ctx->cert_buf) { free(ctx); return NULL; }
    memcpy(ctx->cert_buf, cert, cert_len);
    ctx->cert_len = cert_len;
    ctx->is_valid = 1;
    g_ctx = ctx;
    return ctx;
}

void ssl_destroy(SSLContext *ctx) {
    if (!ctx) return;
    free(ctx->cert_buf);
    free(ctx);
    /* 漏洞: g_ctx 仍指向已释放的 ctx */
}

int ssl_renegotiate(void) {
    /* CWE-416: g_ctx 可能已被 ssl_destroy 释放 */
    if (g_ctx && g_ctx->is_valid) {
        printf("renegotiating with cert_len=%zu\n", g_ctx->cert_len);
        return 1;
    }
    return 0;
}
