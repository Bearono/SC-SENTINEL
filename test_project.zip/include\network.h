#ifndef NETWORK_H
#define NETWORK_H
#include <stddef.h>
typedef struct Conn Conn;
void *alloc_recv_buffer(size_t count, size_t size);
int   recv_frame(unsigned char *buf, size_t buf_size, size_t recv_len);
Conn *conn_acquire(int fd, const char *addr);
void  conn_release(Conn *c);
void  conn_debug_print(Conn *c);
#endif
